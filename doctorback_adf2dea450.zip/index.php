<?php require('onepage.php') ?>
<!DOCTYPE html>
<html lang="ru-RU">

<head>
<title>Doctor Back -магнитный инновационный корректор осанки</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=480">
	<meta name="description" content="Вы забудете, что такое боли в спине! Благодаря фиксации осанки строго в здоровом положении">
	<link rel="shortcut icon" href="hzp278r_.png" type="image/x-icon">
	<link rel="stylesheet" href="agi6mauv.css">
	<link rel="stylesheet" href="m_ziya8n.css">
<meta property="og:type" content="article"/>
<meta property="og:title" content="Корректор осанки Doctor Back"/>
<meta property="og:description" content="Уникальный корректор для спины, который восстанавливает физиологическую линию позвоночника и избавляет от сутулости. Doctor Back способствует снятию отеков, устранению воспалений, восстановлению нервной и сердечно-сосудистой систем. За счёт удобной липучки, корректор плотно и комфортно располагается на теле, не сковывая движений и оставаясь совершенно незаметным под одеждой."/>
<meta property="og:url" content=""/>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

</head>
<body>

<div class="main_wrapper">
		<header class="offer_section offer3">
			<div class="title_block clearfix">
				<img src="5wmz2kbb.png" alt="" class="logo">
				<p class="subtitle">Doctor Back Магнитный инновационный корректор осанки </p>
			</div>
			<div class="timer_block clearfix">
				<p>Это предложение закончится через:</p>
				<div class="timer clearfix">
					<div class="timer_item">
						<div class="text">дней</div>
						<div class="count">00</div>
					</div>
					<div class="timer_item">
						<div class="text">часов</div>
						<div class="count hours">22</div>
					</div>
					<div class="timer_item">
						<div class="text">минут</div>
						<div class="count minutes">00</div>
					</div>
					<div class="timer_item">
						<div class="text">секунд</div>
						<div class="count seconds">00</div>
					</div>
				</div>
			</div>
			<div class="image_block">
				<img class="offer_image" src="tdp76cpd.jpg" alt="">
				<div class="sale"><p>Скидка -53%</p></div>
				<div class="pulse_list">
					<div class="pulse_item"></div>
					<div class="pulse_item"></div>
				</div>
			</div>
			<div class="benefits_list clearfix">
				<div class="benefit_item">100% гарантия качества</div>
				<div class="benefit_item">Предложение ограниченно</div>
				<div class="benefit_item">Оплачиваете при получении</div>
			</div>
			<div class="price_block clearfix">
				<div class="price_item old">
					<div class="text">Обычная цена:</div>
					<div class="value"><?= $oldPriceHtml ?> <?= $currencyDisplayHtml ?></div>
				</div>
				<div class="price_item new">
					<div class="text"><span>Экономия 53%</span></div>
					<div class="value"><?= $newPriceHtml ?> <?= $currencyDisplayHtml ?></div>
				</div>
			</div>
			<ul>
				<li>100% стабилизация нагрузки на позвоночник</li>
				<li>Хронические боли исчезают </li>
				<li>Положение спины фиксируется и выравнивается</li>
			</ul>
			<a href="#order_form" class="button" onclick="ym(57660301, 'reachGoal', 'header'); return true;">Заказать со скидкой</a>
			<div class="products_count">Осталось <b>11</b> штук по акции</div>
		</header>
		<img class="image" src="ct74b-of.jpg" alt="">
		<section class="sect2 dark_theme">
			<h2 class="title"><span>Doctor Back</span> навсегда решит ваши проблемы</h2>
			<div class="benefits_list3">
				<div class="benefit_item">
					<img src="chvdvm0c.jpg" alt="">
					<div class="text_block">
						<h4>Боли в спине</h4>
						<p>Вы больше никогда не вспомните как мучительно,когда болит спина! Так как эффективная фиксация осанки будет исключительно в здоровом положении,благодаря воздействию активных магнитов</p>
					</div>
				</div>
				<div class="benefit_item">
					<img src="g2zbzzxa.jpg" alt="">
					<div class="text_block">
						<h4>Перманентная усталость</h4>
						<p>Усталость - следствие остеохондроза. Благодаря Doctor Back,менее,чем через неделю, вы почувствуете, что энергия переполняет вас на протяжении всего дня.</p>
					</div>
				</div>
				<div class="benefit_item">
					<img src="jwr_eah-.jpg" alt="">
					<div class="text_block">
						<h4>Лишние килограммы создают дополнительную нагрузку</h4>
						<p>Doctor Back равномерно распределяет нагрузку на все мышцы позвоночника, что делает невозможным искривления при лишних килограммах</p>
					</div>
				</div>
				<div class="benefit_item">
					<img src="mqvhume_.jpg" alt="">
					<div class="text_block">
						<h4>Нет возможности ходить к специалистам?</h4>
						<p>Ежедневное использование корректора поспособствует приведению осанки в форму, а мышечный корсет в тонус</p>
					</div>
				</div>
			</div>
		</section>
		<section class="description_section">
			<h2 class="title"><span>Инновационный метод коррекции осанки</span></h2>
			<div class="text_block">
				<p><b>Корректор Doctor Back – это новейшее изобретение от немецких ученых,в его разработке учавствовали лучшие мировые ортопеды.</b></p>
			</div>
			<div class="video_block">
			<iframe width="560" height="315" src="https://www.youtube.com/embed/87tqn245mPA" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>                                                                                                 
			</div>
			<div class="text_block">
				<p>Восстановление физиологической линии позвоночника и избавление от сутулости происходит буквально на Ваших глазах. <b>Носить изделие можно в течение целого дня.</b> Он совершенно незаметен под одеждой.</p>
			</div>
			<img src="_m2yg3gi.jpg" alt="" class="img1">
			<div class="text_block">
				<p><b>Doctor Back не только способствует выпрямлению спины,но и  снятию отеков,</b> устранению воспалений, восстановлению нервной и сердечно-сосудистой систем. Удобная липучка помогает располагать корректор на теле плотно и комфортно, не сковывая движений.</p>
			</div>
			<div class="alert">
				<img src="5wmz2kbb.png" alt="" class="logo">
				<p>Активная жизнь-это счастье! Вы заслуживаете это!</p>
			</div>
			<a href="#order_form" class="button">Заказать со скидкой</a>
		</section>
		<section class="sect3">
			<h2 class="title">Как работает Doctor Back?</h2>
			<div class="img">
				<img src="_a5onfrd.jpg" alt="">
				<img src="nlx-179n.jpg" alt="" class="prod">
			</div>
			<ul class="list1">
				<li>Без помощи специалистов ваша осанка укрепится,а позвоночник выровняется.</li>
				<li>Благодаря лямкам корректора плечи физиологически оттягиваются назад.<br> Благодаря этому спина расправляется,а корпус фиксируется в правильном положении.</li>
				<li>Встроенные активные магниты создают мощное электромагнитное поле, оно улучшает кровообращение и тонизирует мышцы спины. </li>
				<li>Магнитное излучение способствует уменьшению отечности, восстанавливается нервная система,все это благоприятно влияет на работу сердца.</li>
			</ul>
			<img src="fn-1gmke.jpg" alt="">
			<img src="ji3zwyhc.jpg" alt="">
			<a href="#order_form" class="button">Заказать со скидкой</a>
		</section>
		<section class="sect4">
			<h2 class="title">Преимущества Doctor back</h2>
			<ul class="benef1">
				<li>
					<img src="7qst8dwo.png" alt="">
					<p><span>Инновационные активные магниты</span> Магнитное поле не только исправляет осанку, оно благотворно действует на весь организм..</p>
				</li>
				<li>
					<img src="_kxrbqsn.png" alt="">
					<p><span>Комфорт</span> Doctor Back выполнен из высококачественных материалов, не жмет и не создает парникового эффекта даже в тёплую погоду</p>
				</li>
				<li>
					<img src="bep0r3pm.png" alt="">
					<p><span>Качество</span> Нет необходимости в каком то специальном уходе, изделие можно стирать каждый день, можете проверить : после тысячи стирок  оно будет выглядеть как новое</p>
				</li>
				<li>
					<img src="eztx8ell.png" alt="">
					<p><span>Цена</span> Doctor back предлагается по лучшей цене. Люди с любым достатком могут позволить приобрести себе такое изобретение!</p>
				</li>
			</ul>
			<a href="#order_form" class="button">Заказать со скидкой</a>
		</section>
		<div style="
    text-align: center;
    margin: 15px auto;
    font-weight: bold;
    font-size: 22px;
">Цвет : черный</div>

		<section class="sect5">
		
			<div class="size_container clearfix">
				<div class="ttl"><p>Размеры</p></div>
				<div class="table">
					<h2 class="title">Размерная таблица</h2>
					<table cellspacing="0" cellpadding="0">
						<tbody>
							<tr>
								<th>Размер:(Рос)</th>
								<th>S <br>(40,42)</th>
								<th>M <br>(44,46)</th>
								<th>L <br>(48,50)</th>
								<th>XL <br>(52,54)</th>
								<th>XXL <br> (56,58)</th>
							</tr>
							<tr>
								<td>Объем груди:</td>
								<td>76-87</td>
								<td>87-93</td>
								<td>93-102</td>
								<td>102-111</td>
								<td>111-119</td>
							</tr>
							<tr>
								<td>Объем талии:</td>
								<td>65-85</td>
								<td>75-95</td>
								<td>85-105</td>
								<td>95-115</td>
								<td>115-125</td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
			<div class="slider owl-carousel">
				<img src="ee3jhm-9.jpg" alt="">
				<img src="h-vtyz8h.jpg" alt="">
				<img src="k5zqc-4g.jpg" alt="">
				<img src="oorntm0f.jpg" alt="">
			</div>
			<img src="m2vwb-db.jpg" alt="">
			<img src="pxz5fm-a.jpg" alt="">
			<a href="#order_form" class="button">Заказать со скидкой</a>
		</section>
<!--
		<section class="sect6">
			<div class="garant">
				<h2 class="title"><span>Гарантия возврата денежных средств</span></h2>
				<p>Мы на 100% уверены в своей продукции, поэтому если вы, правильно применив к ней инструкцию, не получите обещанного результата, мы вернём вам деньги в полном объёме.</p>
				<img src="images/garant_img.jpg" alt="">
			</div>
			<img src="images/s6_img.jpg" alt="">
		</section>
-->
		<section class="reviews4_section">
			<h2 class="title">Отзывы покупателей</h2>
			<div class="reviews_stats_block">
				<p><b>94%</b> покупателей рекомендуют этот товар</p>
				<div class="line"></div>
			</div>
			<div class="reviews_list4 owl-carousel">
				<div class="review_item">
					<img class="photo" src="eo35e22l.jpg" alt="">
					<div class="text_block">
						<div class="author_info">«...использование корсета уже на 3-ем часу оправдала ожидания»</div>
						<p> Моя работа связанна с частыми разъездами по городу, порой в дороге находишься по 7-8 часов в день. После 3-го часа спина уже дико начинает ныть. Покупая Doctor Back, сильно надеялся на его помощь. Как же я был удивлен,что использование корсета уже на 3ем часу оправдала ожидания на 100%. Через неделю ежедневного использования, даже жена заметила, что моя осанка стала походить на осанку гимнаста: идеально ровная и плечи широко расправлены.</p>
						<div class="name">Эдуард Молотов, 41 год, Москва</div>
					</div>
				</div>
				<div class="review_item">
					<img class="photo" src="h872vdzk.jpg" alt="">
					<div class="text_block">
						<div class="author_info">« Doctor Back поспособствовал тому,что я могу сидеть часами с ровной спиной уже даже не надевая его»</div>
						<p> Всегда знала, как необходимо сидеть с ровной спиной.Когда вспоминаю об- выпрямляюсь. Но уже через 15 минут,забываю и снова сижу сгорбленная, так как мышцы устают. Заказала корректор для спины, чтобы решить данный вопрос. Можете себе представить,что уже на следующий день я совершенно его не чувствовала. Более того, Doctor Back поспособствовал тому,что я могу сидить часами с ровной спиной уже даже не надевая его)</p>
						<div class="name">Ольга Климова, 31 год, Санкт-Петербург</div>
					</div>
				</div>
				<div class="review_item">
					<img class="photo" src="k3zaaqvi.jpg" alt="">
					<div class="text_block">
						<div class="author_info">«Спина действительно фиксируется в здоровом положении»</div>
						<p>Я офисный работник и сижу за компьютерами целыми днями. И конечно же шейный отдел позвоночника беспокоит давно и регулярно. Чтобы помочь своему позвоночнику решил приобрести octor Back. Доставили быстро, всего за 2 дня. Спина действительно фиксируется в здоровом положении. Про мучительные боли в шее забыл уже к вечеру первого дня. Теперь сижу с идеально ровной спиной и остаюсь бодрым до конца рабочего дня!</p>
						<div class="name">Алексей Мулов, 33 года, Москва</div>
					</div>
				</div>
			</div>
		</section>
		 
			<section class="order_info1_section">
				<h2 class="title">Доставка и оплата</h2>
				<div class="order_info_list1">
					<div class="info_item clearfix">
						<div class="icon_block">
							<img src="juxwmu1i.png" alt="">
						</div>
						<div class="text_block">
							<h4>Заявка</h4>
							<p>Внесите свои контактные данные в форму заказа на нашем сайте</p>
						</div>
					</div>
					<div class="info_item clearfix">
						<div class="icon_block">
							<img src="mc1t27yh.png" alt="">
						</div>
						<div class="text_block">
							<h4>Звонок</h4>
							<p>Наш специалист свяжется с вами и поможет подобрать правильный размер</p>
						</div>
					</div>
					<div class="info_item clearfix">
						<div class="icon_block">
							<img src="p9u37iuf.png" alt="">
						</div>
						<div class="text_block">
							<h4>Отправка</h4>
							<p>Доставляем курьером на следующий день</p>
						</div>
					</div>
					<div class="info_item clearfix">
						<div class="icon_block">
							<img src="s3y0lufe.png" alt="">
						</div>
						<div class="text_block">
							<h4>Получение</h4>
							<p>Оплата товара происходит при получении.  </p>
						</div>
					</div>
				</div>
			</section>
			<section class="offer_section offer3">
				<div class="title_block clearfix">
				<img src="5wmz2kbb.png" alt="" class="logo">
				<p class="subtitle">Doctor Back Инновационный корректор осанки </p>
			</div>
			<div class="timer_block clearfix">
				<p>Это предложение закончится через :</p>
				<div class="timer clearfix">
					<div class="timer_item">
						<div class="text">дней</div>
						<div class="count">00</div>
					</div>
					<div class="timer_item">
						<div class="text">часов</div>
						<div class="count hours">22</div>
					</div>
					<div class="timer_item">
						<div class="text">минут</div>
						<div class="count minutes">00</div>
					</div>
					<div class="timer_item">
						<div class="text">секунд</div>
						<div class="count seconds">00</div>
					</div>
				</div>
			</div>
			<div class="image_block">
				<img class="offer_image" src="tdp76cpd.jpg" alt="">
				<div class="sale"><p>Скидка -53%</p></div>
				<div class="pulse_list">
					<div class="pulse_item"></div>
					<div class="pulse_item"></div>
				</div>
			</div>
				<div class="benefits_list clearfix">
					<div class="benefit_item">100% гарантия качества</div>
					<div class="benefit_item">Предложение ограниченно</div>
					<div class="benefit_item">Оплачиваете при получении</div>
				</div>
				<div class="price_block clearfix">
					<div class="price_item old">
						<div class="text">Обычная цена:</div>
						<div class="value"><?= $oldPriceHtml ?> <?= $currencyDisplayHtml ?></div>
					</div>
					<div class="price_item new">
						<div class="text"><span>Вы экономите 53%</span></div>
						<div class="value"><?= $newPriceHtml ?> <?= $currencyDisplayHtml ?></div>
					</div>
				</div>
				<h4>Оставьте заявку прямо сейчас</h4>
				<form id="order_form" class="main-order-form order_form" action="" method="post">
				
				<?= countrySelect() ?>	
				 
					<input class="field" type="text" name="name" placeholder="Введите ваше имя"    >
					<input class="field" type="tel" name="phone" placeholder="Введите ваш телефон" required  >
					<button class="button">Заказать со скидкой</button>
</form>
				<div class="products_count">Осталось <b>11</b> штук по акции</div>
			</section>
			<div class="conf">100% конфиденциальность. <br>Ваши данные не будут переданы третьим лицам.</div>
			<div class="footer_section">
				<footer class="cpu center">
				    <section class="cpu center">
				       <div style="text-align: center;margin: 10px auto;display: block;font-size: 14px;line-height: 26px;">
				       	<?= footer() ?>
						</div>	   
					</section>
				</footer>
			</div>
		<!-- scripts -->
		
    




</div>

<style>
  .form-control{
    display: block;
    margin: 0 auto 20px;
    padding: 0 20px 0 80px;
    width: 400px;
    height: 66px;
    border: 1px solid #e6e6e6;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
    background-color: #fff;
    font-family: 'AvenirNextCyr', sans-serif;
    font-weight: 400;
    font-size: 16px;
    color: #333;

  }
</style>
		
<script src="owl.carousel.min.js"></script>
<script src="index.js"></script>


		
 
	</body>
	
 
</html>