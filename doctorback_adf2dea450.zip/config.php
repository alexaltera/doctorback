<?php

$apiKey = 'wFhZr7iL7UnLRqZo47VU2w7NYNHLye2EBKFlS9JSmYxHxe';          // Ключ доступа к API
$offer_id = 4744;         // для каждого оффера свой айди, надо уточнять его в админке или у суппортов
$stream_hid = '7NyT0N4b';     // id потока

$default_main_site = 'http://api.cpa.tl';
$apiSendLeadUrl = 'http://api.cpa.tl/api/lead/send_archive';
$apiGetLeadUrl = 'http://api.cpa.tl/api/lead/feed';

$dataOffers = '{"19365":{"price":"1590","name":"\u041c\u0430\u0433\u043d\u0438\u0442\u043d\u044b\u0439 \u0438\u043d\u043d\u043e\u0432\u0430\u0446\u0438\u043e\u043d\u043d\u044b\u0439 \u043a\u043e\u0440\u0440\u0435\u043a\u0442\u043e\u0440 \u043e\u0441\u0430\u043d\u043a\u0438 DOCTOR BACK","country":{"code":"RU","name":"\u0420\u043e\u0441\u0441\u0438\u044f"},"price2":"3390","id":19365,"currency":{"code":"RUB","name":"\u0440\u0443\u0431"}}}';
$dataOffer = '{"price":"1590","name":"\u041c\u0430\u0433\u043d\u0438\u0442\u043d\u044b\u0439 \u0438\u043d\u043d\u043e\u0432\u0430\u0446\u0438\u043e\u043d\u043d\u044b\u0439 \u043a\u043e\u0440\u0440\u0435\u043a\u0442\u043e\u0440 \u043e\u0441\u0430\u043d\u043a\u0438 DOCTOR BACK","country":{"code":"RU","name":"\u0420\u043e\u0441\u0441\u0438\u044f"},"price2":"3390","id":19365,"currency":{"code":"RUB","name":"\u0440\u0443\u0431"}}';
$productName = 'Магнитный инновационный корректор осанки DOCTOR BACK';
$invoice = 'index.php';
$push_link = '';
$language = 'ru';
$companyInfo = array('address' => '344068, РОСТОВСКАЯ ОБЛАСТЬ, ГОРОД РОСТОВ-НА-ДОНУ, ПЕРЕУЛОК АШХАБАДСКИЙ, ДОМ 12, КВАРТИРА 11', 'detail' => 'ОБЩЕСТВО С ОГРАНИЧЕННОЙ ОТВЕТСТВЕННОСТЬЮ "ПРОД-СТРОЙ" ОГРН: 1176196004797 ИНН: 6165206011 КПП: 616501001');

if(!$apiKey){
    echo 'Ключ доступа к API не определен. Получите в личном кабинете или обратитесь в службу поддержки';
    die;
}

if(!$offer_id){
    echo 'ID оффера не определен';
    die;
}
